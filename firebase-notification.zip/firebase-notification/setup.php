<?php
/*
Plugin Name: Firebase Notification
Plugin URI: https://www.dimofinf.net/
Description: A plugin to send Firebase Notifications to all users using topic-based subscriptions.
Author: dimofinf
Author URI: https://www.dimofinf.net/
*/

use Firebase\JWT\JWT;
use GuzzleHttp\Client;

defined('ABSPATH') or die('No script kiddies please!');

define('DIMOPATH', plugin_dir_path(__FILE__));

// Include Firebase autoload if available
if (file_exists(DIMOPATH . 'Firebase/vendor/autoload.php')) {
    require DIMOPATH . 'Firebase/vendor/autoload.php';
}

// Function to get Firebase Access Token
function get_firebase_access_token($service_account_key) {
    $token_uri = $service_account_key['token_uri'];
    $client_email = $service_account_key['client_email'];
    $private_key = $service_account_key['private_key'];

    $jwt = [
        'iat' => time(),
        'exp' => time() + 3600,
        'aud' => $token_uri,
        'iss' => $client_email,
        'scope' => 'https://www.googleapis.com/auth/cloud-platform',
    ];

    $key = openssl_pkey_get_private($private_key);
    if (!$key) {
        error_log('Failed to get private key.');
        return false;
    }

    $assertion = JWT::encode($jwt, $key, 'RS256');

    try {
        $response = (new Client())->post($token_uri, [
            'form_params' => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $assertion,
            ],
        ]);

        $body = json_decode($response->getBody(), true);
        return $body['access_token'] ?? false;

    } catch (Exception $e) {
        error_log("Error fetching access token: " . $e->getMessage());
        return false;
    }
}

function send_firebase_notification($title, $body) {
    $service_account_key = json_decode(file_get_contents(DIMOPATH . 'alajlan-f408f-firebase-adminsdk-qihpk-e2a27d2d9a.json'), true);

    if (!$service_account_key) {
        error_log('Failed to read service account key.');
        return false;
    }

    $access_token = get_firebase_access_token($service_account_key);

    if (!$access_token) {
        error_log('Failed to get Firebase access token.');
        return false;
    }

    $firebase_project_id = $service_account_key['project_id'];

    // إعداد الرسالة
    $notification = [
        'message' => [
            'topic' => 'general', // Using a general topic for all users
            'notification' => [
                'title' => $title,
                'body' => $body,
            ],
        ],
    ];

    $client = new Client();
    try {
        $response = $client->post("https://fcm.googleapis.com/v1/projects/{$firebase_project_id}/messages:send", [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json',
            ],
            'json' => $notification,
        ]);

        return $response->getBody()->getContents();
    } catch (Exception $e) {
        error_log("Error sending notification: " . $e->getMessage());
        return false;
    }
}

// Hook to send notifications when a post is published
function on_post_publish($post_id) {
    // Skip if this is a post revision
    if (wp_is_post_revision($post_id)) {
        return;
    }

    $post = get_post($post_id);
    $post_title = get_the_title($post_id);
    $post_excerpt = wp_trim_words($post->post_content, 20); // Shortened content for the notification

    // Only proceed if the post is published
    if ($post->post_status == 'publish') {
        // Send notification to the "general" topic
        send_firebase_notification($post_title, $post_excerpt);
    }
}

// Register the hook to send notifications upon post publication
add_action('publish_post', 'on_post_publish');
